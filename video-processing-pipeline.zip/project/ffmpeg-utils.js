// FFmpeg helper functions
const { exec } = require('child_process');

const analyzeVideo = (filePath) => {
  return new Promise((resolve, reject) => {
    const command = `ffprobe -v quiet -print_format json -show_streams "${filePath}"`;
    exec(command, (error, stdout) => {
      if (error) return reject(error);
      const metadata = JSON.parse(stdout);
      const videoStream = metadata.streams.find(s => s.codec_type === 'video');
      resolve({
        codec: videoStream.codec_name,
        resolution: `${videoStream.width}x${videoStream.height}`,
        bitrate: videoStream.bit_rate,
        fps: videoStream.r_frame_rate
      });
    });
  });
};

const encodeVideo = (inputPath, outputPath, resolution, codec) => {
  return new Promise((resolve, reject) => {
    const command = `ffmpeg -i "${inputPath}" -vf scale=${resolution} -c:v ${codec} "${outputPath}"`;
    exec(command, (error) => {
      if (error) return reject(error);
      resolve();
    });
  });
};

module.exports = { analyzeVideo, encodeVideo };
